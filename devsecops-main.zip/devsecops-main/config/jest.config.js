module.exports = {
  testEnvironment: "node",
  "moduleNameMapper": {
  "/^@mocks$/": "/Users/sidi/Documents/Documents - siddharth’s MacBook Air/devops/tests/setup.js"
}
}